<?php
    include"include/nav.php";
?>
<div class="page_back">

<!--  Don't touch class page_back  -->
    
    <div class="container-fluid">
        <div class="text-center text-white mb-2">
            <h2 class="display-4 h2">Welcome to Event Management Portal</h2>
        </div>
        <div class="row pt-5">
            <div class="col-1 back_side">
            </div>
            <div class="col-10 back_content">
                <div class="text-light font-weight-bold text-justify">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. In, deleniti consectetur mollitia tenetur, beatae minima rem facilis eligendi non, eaque, voluptate enim fuga illo veritatis quaerat corrupti deserunt illum cumque! Ullam accusantium provident ea at suscipit dolores officiis ex voluptatibus repellat quo. Voluptas voluptatem, aliquam cum hic sequi consectetur ducimus numquam, expedita mollitia illo nulla exercitationem reprehenderit saepe soluta alias eaque autem quae ut quisquam doloremque. Nobis soluta consectetur itaque voluptates excepturi magnam provident, quas molestiae officiis officia! Quos eveniet, dolor nemo at voluptates distinctio ab natus quidem accusamus laboriosam. Inventore nihil possimus tempore facere ipsam iure odit omnis animi!
                </div>
            </div>
            <div class="col-1">  
            </div>
        </div>
    </div>

</div> 
<?php
    include"include/footer.php";
?>