<?php
    include "include/nav.php";
?>


<div class="page_back">
    
    
    <div class="container">
        
        
        <div class="text-center text-white">
            
            <h1 class="display-2">About Us</h1>
            
        </div>
        
        <div class="row text-white h4 pt-5">
            <div class="col-2">
                <div class="font-weight-bold">
                    <h3 class="h3">Created By:</h3>
                </div>
            </div>
            <div class="col-8">
                
                <div class="row justify-content-center back_about">
                    <div class="about_screen">
                        <div class="col-md-5 about_back">
                            <div class="input-group">
                                <label for="">Krupa</label>
                            </div>
                            <div class="input-group">
                                <label for="">....</label>
                            </div>
                            <div class="input-group">
                                <label for="">....</label>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="col-2">
            </div>
        </div>
        
        
        
    </div>
    
    
    
    
    
</div>





<?php

    include "include/footer.php";

?>