    <div class="footer">
        <div class="row foter">
            <div class="col-md-1">

            </div>
            <div class="col-md-3 fotr_work">
                <div class="text-center text-white">
                    <h4 class="h4 pb-2">ABOUT US</h4>
                    <ul class="">
                        <li class="">
                            <div class="fot_back">
                                <div class="fot_front">
                                    <div class="fot_text">Krupa</div>
                                </div>
                            </div>
                        </li>
                        <li class="">
                            <div class="fot_back">
                                <div class="fot_front">
                                    <div class="fot_text">...</div>
                                </div>
                            </div>
                        </li>
                        <li class="">
                            <div class="fot_back">
                                <div class="fot_front">
                                    <div class="fot_text">...</div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center text-white feedback_control">
                    <h4 class="h4 pb-2">CONTACT US</h4>
                    
                    <div class="form-groups">
                        <div class="fot_con_back">
                           <div class="text_none">xyz</div>
                        </div>
                    </div>
                    <div class="fot_con_text">
                        <h4 class="h4"></h4>
                        <h4 class="h4"></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="text-center text-white">
                    <h4 class="h4 pb-2">HELP</h4>
                    <a class="nav-link" href="">Admin</a>
                    <br />
                    <a class="nav-link" href="">User</a>
                </div>
            </div>
            <div class="col-md-1"></div>
        </div>
        <div class="text-center">
            <h3 class="h2">EMS at &copy; 2019</h3>
        </div>
    </div>

</body>
</html>